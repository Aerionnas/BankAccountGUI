/**
 * BankAccountGUI.java 
 * 
 * This class creates a GUI for my BankAccount.java class. It allows the user to input their own balance 
 * into a textfield, and gives them two options: withdraw or deposit funds. To prevent invalid inputs, my code
 * does feature some input validation.
 * 
 * Basic Feature: JButton, JTextArea, JTextField, JPanel, ActionListener
 * Author: Aerionna Stephenson
 * 
 */

package BankAccount;

import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

/**
 * This is a GUI for my Bank Account class
 */

public class BankAccountGUI {

	public static void main(String[] args) {
		// new instance of BankAccoun
		BankAccount myBankAccount = new BankAccount();
		// frame
		JFrame window = new JFrame("Bank Account Application");
		// panel
		JPanel panel1 = new JPanel();
		// text field
		JTextField textField1 = new JTextField("0");
		// textArea
		JTextArea textArea1 = new JTextArea("Enter your current balance please");
		// user cannot edit this field
		textArea1.setEditable(false);

		// buttons
		JButton enter = new JButton("enter");
		JButton withdraw = new JButton("withdraw");
		JButton deposit = new JButton("deposit");
		JButton okWithdraw = new JButton("ok");
		JButton okDeposit = new JButton("ok");

		panel1.setLayout(new GridLayout(0, 1));

		// these components are added to the panel
		panel1.add(textArea1);
		panel1.add(textField1);
		panel1.add(enter);

		/**
		 * this handles the event when a user presses the "enter" button. It set their
		 * initial balance whatever the user input into the text field. It also
		 * validates the user's input to ensure that they are inputing a number.
		 */

		enter.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				boolean valid = false;
				double balance = 0.0;

				while (!valid) {
					try {
						// the amount that is entered by the user is taken in and is set as the new
						// balance for the account
						balance = Double.parseDouble(textField1.getText().trim());
						myBankAccount.setBalance(balance);
						valid = true;
					} catch (NumberFormatException ex) {
						JOptionPane.showMessageDialog(window, "Please enter a valid number.");
						return; // Let the user try again — don't proceed to the next steps
					}
				}

				textArea1.setText("Okay, got it. What can I help you with today?");
				textField1.setVisible(false);
				enter.setVisible(false);
				panel1.add(withdraw);
				panel1.add(deposit);
				panel1.revalidate(); // Refresh layout
			}
		});

		/**
		 * this handles the event when a user presses the "withdraw" button. The user is
		 * able to enter the amount that they would like to withdraw and the appropriate
		 * components are displayed to the panel.
		 */
		withdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea1.setText("How much would you like to withdraw?");
				textField1.setText("0");
				textField1.setVisible(true);

				enter.setVisible(false);
				withdraw.setVisible(false);
				deposit.setVisible(false);

				panel1.add(okWithdraw);
				okWithdraw.setVisible(true);
				panel1.revalidate();
			}
		});

		okWithdraw.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try {
					double amount = Double.parseDouble(textField1.getText().trim());

					if (amount <= 0) {
						textArea1.setText("Please enter a positive amount.");
					} else if (amount > myBankAccount.getBalance()) {
						textArea1.setText(
								"Insufficient funds. You must enter an amount lower than your current balance ($"
										+ myBankAccount.getBalance() + ").");
					} else {
						myBankAccount.withdraw(amount);
						textArea1.setText(
								"Withdrawal successful. Your current balance is $" + myBankAccount.getBalance() + ".");
						textField1.setVisible(false);
						okWithdraw.setVisible(false);

						// Optionally show the deposit/withdraw buttons again
						withdraw.setVisible(true);
						deposit.setVisible(true);
					}
				} catch (NumberFormatException ex) {
					JOptionPane.showMessageDialog(null, "Please enter a valid number.");
				}
			}
		});

		deposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				textArea1.setText("How much would you like to deposit?");
				textField1.setText("0");
				textField1.setVisible(true);
				enter.setVisible(false);
				withdraw.setVisible(false);
				deposit.setVisible(false);
				panel1.add(okDeposit);
				okDeposit.setVisible(true);

//				 
			}
		});

		okDeposit.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				double amount = Double.parseDouble(textField1.getText().trim());
				myBankAccount.deposit(amount);
				textArea1
						.setText("Withdrawal successful. Your current balance is $" + myBankAccount.getBalance() + ".");
				textField1.setVisible(false);
				okDeposit.setVisible(false);

				// Optionally show the deposit/withdraw buttons again
				withdraw.setVisible(true);
				deposit.setVisible(true);
				textArea1.setText("Your current balance is $" + myBankAccount.getBalance() + ".");
				textArea1.setVisible(true);
				textField1.setVisible(false);
				okDeposit.setVisible(false);

//				 
			}
		});

		window.setContentPane(panel1);
		window.setSize(500, 500);
		window.setLocation(300, 300);
		window.setVisible(true);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

}
