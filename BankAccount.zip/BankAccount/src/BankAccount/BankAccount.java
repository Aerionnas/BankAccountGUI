package BankAccount;

/**
 * BankAccount.Java is a class that allows for people to make deposit and
 * withdrawals. It includes a default constructor and the appropriate methods.
 * This class will be paired with the BankAccounGUI.
 * 
 * Author: Aerionna Stephenson
 */
public class BankAccount {
	private double balance;

	// the users starting balance will be 0.
	public BankAccount() {
		this.balance = 0.0;
	}

	/**
	 * Returns the current balance of the bank account.
	 *
	 * @return the current balance
	 */
	public double getBalance() {
		return balance;
	}

	/**
	 * Sets the balance of the bank account.
	 *
	 * @param the new balance that the current balance will be updated to
	 */
	public void setBalance(double balance) {
		this.balance = balance;
	}

	/**
	 * this deposits a certain amount into the bank account
	 *
	 * @param the amount the user wants to deposit into their bank account
	 */
	public void deposit(double amount) {
		this.balance += amount;
	}

	/**
	 * this withdraws a certain amount from their bank account
	 *
	 * @param the amount the user wants to withdraw from their bank account
	 */
	public void withdraw(double amount) {
		this.balance -= amount;
	}

}
