/**
 * 
 */
/**
 * 
 */
module BankAccount {
	requires java.desktop;
}